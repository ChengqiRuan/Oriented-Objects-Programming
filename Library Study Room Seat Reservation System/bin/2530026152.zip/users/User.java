package users;

public abstract class User {
	private String username;
	private String password;
	public User(String username, String password) {
		this.username=username;
		this.password=password;
	}
	public void login() {
		System.out.println("Welcome"+username);
	}
	public String getUsername() {
		return this.username;
	}
	public void setUsername(String username) {
		this.username=username;
	}
	public String getPassword() {
		return this.password;
	}
	public void setPassword(String password){
		this.password=password;
	}
}
